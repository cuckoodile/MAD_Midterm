import { Pressable, StyleSheet, Text, View } from "react-native";
import React from "react";
import { Link, useRouter } from "expo-router";

export default function Settings() {
  const router = useRouter();

  return (
    <View>
      <Text>Settings</Text>

      <Link href={"/"} style={styles.button}>
        <Text>Log out</Text>
      </Link>
    </View>
  );
}

const styles = StyleSheet.create({
  button: {
    padding: 10,
    borderWidth: 1,
    borderRadius: 10,
  },
});
