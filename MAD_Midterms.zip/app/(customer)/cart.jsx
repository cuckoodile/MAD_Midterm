import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function Cart() {
  return (
    <View>
      <Text>Cart</Text>
    </View>
  )
}

const styles = StyleSheet.create({})