import { StyleSheet, Text, View } from "react-native";
import React, { useCallback, useState } from "react";
import { useFocusEffect } from "expo-router";
import { fetchAll, fetchProduct } from "@/sqlConfig";

import Card from "../components/Card";

export default function Index() {
  const [refresh, setRefresh] = useState(false);
  const [currencyData, setCurrencyData] = useState([]);
  const [typeData, setTypeData] = useState([]);
  const [productData, setProductData] = useState([]);

  useFocusEffect(
    useCallback(() => {
      fetchAll("currency", setCurrencyData);
      fetchAll("type", setTypeData);
      fetchProduct(setProductData);
    }, [refresh])
  );

  return (
    <View>
      {/* Card List */}
      {productData?.map((product) => (
        <Card data={product} key={product.id} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({});
